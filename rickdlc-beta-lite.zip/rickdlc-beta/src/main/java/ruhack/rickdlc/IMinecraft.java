package ruhack.rickdlc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.util.Window;

public interface IMinecraft {
   MinecraftClient mc = MinecraftClient.getInstance();
   Window window = MinecraftClient.getInstance().getWindow();
   Tessellator tessellator = Tessellator.getInstance();
   RenderTickCounter tickCounter = mc.getRenderTickCounter();
}
