package ruhack.rickdlc.util.rpc.callbacks;

import com.sun.jna.Callback;
import ruhack.rickdlc.util.rpc.utils.DiscordUser;

public interface JoinRequestCallback extends Callback {
   void apply(DiscordUser var1);
}
