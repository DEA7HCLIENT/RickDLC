package ruhack.rickdlc.util.interfaces;

public interface IBuiltChunkAnimator {
   float getAnimation();

   void setAnimation(float var1);
}
