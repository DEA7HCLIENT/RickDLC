package ruhack.rickdlc.util.animations;

public enum Direction {
   FORWARDS,
   BACKWARDS;
}
