package ruhack.rickdlc.util.player.swap.script;

@FunctionalInterface
public interface ScriptAction {
   void perform();
}
