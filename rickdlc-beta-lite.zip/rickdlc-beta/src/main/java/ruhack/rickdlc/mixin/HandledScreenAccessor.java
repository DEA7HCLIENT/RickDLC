package ruhack.rickdlc.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(HandledScreen.class)
public interface HandledScreenAccessor {
   @Accessor("x")
   int rickdlc$getX();

   @Accessor("y")
   int rickdlc$getY();

   @Accessor("backgroundWidth")
   int rickdlc$getBackgroundWidth();

   @Accessor("backgroundHeight")
   int rickdlc$getBackgroundHeight();
}
