package ruhack.rickdlc.mixin;

public interface IClientPlayerInteractionManager {
   void meteor$syncSelected();
}
