package ruhack.rickdlc.system.modulesystem.impl.rage;

import ruhack.rickdlc.system.eventsystem.api.EventHandler;
import ruhack.rickdlc.system.eventsystem.impl.KeyEvent;
import ruhack.rickdlc.system.modulesystem.ModuleStructure;
import ruhack.rickdlc.system.modulesystem.category.ModuleCategory;
import ruhack.rickdlc.system.modulesystem.setting.implement.BindSetting;
import ruhack.rickdlc.system.modulesystem.setting.implement.SliderSettings;
import ruhack.rickdlc.util.istance.Instance;
import ruhack.rickdlc.util.string.chat.ChatMessage;

public class ElytraTarget extends ModuleStructure {
   public SliderSettings elytraFindRange = new SliderSettings("Дистанция наводки", "Дальность поиска цели во время полета на элитре", 32.0F).range(6.0F, 64.0F);
   public SliderSettings elytraForward = new SliderSettings("Значение перегона", "Сила перегона от противника", 3.0F).range(0.0F, 6.0F);
   final BindSetting forward = new BindSetting("Кнопка вкл/выкл перегона", "");
   public static boolean shouldElytraTarget = false;

   public static ElytraTarget getInstance() {
      return Instance.get(ElytraTarget.class);
   }

   public ElytraTarget() {
      super("ElytraTarget", "Таргетит таргета ауры на элитре", ModuleCategory.RAGE);
      this.settings(this.elytraFindRange, this.elytraForward, this.forward);
   }

   @EventHandler
   private void onEventKey(KeyEvent e) {
      if (e.isKeyDown(this.forward.getKey())) {
         shouldElytraTarget = !shouldElytraTarget;
         ChatMessage.brandmessage("Elytra Forward " + (shouldElytraTarget ? "включен" : "выключен"));
      }
   }
}
