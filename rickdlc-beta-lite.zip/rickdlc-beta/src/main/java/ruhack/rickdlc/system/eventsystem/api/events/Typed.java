package ruhack.rickdlc.system.eventsystem.api.events;

public interface Typed {
   byte getType();
}
