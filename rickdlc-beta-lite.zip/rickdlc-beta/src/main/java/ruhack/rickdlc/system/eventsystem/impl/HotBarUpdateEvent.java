package ruhack.rickdlc.system.eventsystem.impl;

import ruhack.rickdlc.system.eventsystem.api.events.callables.EventCancellable;

public class HotBarUpdateEvent extends EventCancellable {
}
