package ruhack.rickdlc.system.eventsystem.impl;

import lombok.Generated;
import ruhack.rickdlc.system.eventsystem.api.events.callables.EventCancellable;

public class EntityColorEvent extends EventCancellable {
   private int color;

   @Generated
   public int getColor() {
      return this.color;
   }

   @Generated
   public void setColor(int color) {
      this.color = color;
   }

   @Generated
   public EntityColorEvent(int color) {
      this.color = color;
   }
}
