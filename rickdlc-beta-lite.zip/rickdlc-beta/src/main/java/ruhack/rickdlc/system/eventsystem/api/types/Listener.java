package ruhack.rickdlc.system.eventsystem.api.types;

public interface Listener {
}
