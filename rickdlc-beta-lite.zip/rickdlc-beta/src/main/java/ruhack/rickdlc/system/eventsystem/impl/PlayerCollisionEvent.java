package ruhack.rickdlc.system.eventsystem.impl;

import lombok.Generated;
import net.minecraft.block.Block;
import ruhack.rickdlc.system.eventsystem.api.events.callables.EventCancellable;

public class PlayerCollisionEvent extends EventCancellable {
   private Block block;

   @Generated
   public void setBlock(Block block) {
      this.block = block;
   }

   @Generated
   public Block getBlock() {
      return this.block;
   }

   @Generated
   public PlayerCollisionEvent(Block block) {
      this.block = block;
   }
}
