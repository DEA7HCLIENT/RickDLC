package ruhack.rickdlc.system.modulesystem.impl.legit;

import ruhack.rickdlc.system.eventsystem.api.EventHandler;
import ruhack.rickdlc.system.eventsystem.impl.InteractEntityEvent;
import ruhack.rickdlc.system.friendsystem.FriendUtils;
import ruhack.rickdlc.system.modulesystem.ModuleStructure;
import ruhack.rickdlc.system.modulesystem.category.ModuleCategory;

public class NoFriendDamage extends ModuleStructure {
   public NoFriendDamage() {
      super("NoFriendDamage", "No Friend Damage", ModuleCategory.LEGIT);
   }

   @EventHandler
   public void onAttack(InteractEntityEvent e) {
      e.setCancelled(FriendUtils.isFriend(e.getEntity()));
   }
}
